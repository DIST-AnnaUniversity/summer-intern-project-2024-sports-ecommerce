document.getElementById("payment-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission

    // Get form values
    var cardNumber = document.getElementById("card-number").value;
    var cardHolder = document.getElementById("card-holder").value;
    var expiry = document.getElementById("expiry").value;
    var cvv = document.getElementById("cvv").value;

    // Perform validation or additional processing as needed

    // Submit the payment details to the server or payment processing service
    // You would typically use AJAX to send the data to your server-side code for further processing

    // Clear form fields
    document.getElementById("card-number").value = "";
    document.getElementById("card-holder").value = "";
    document.getElementById("expiry").value = "";
    document.getElementById("cvv").value = "";

    // Show success message or perform any other desired action
    
});
