


<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require 'vendor/autoload.php'; // Make sure to include the autoload file

\Stripe\Stripe::setApiKey('sk_test_51QAyfXCGkZKvgsf4auMfJ0UUs6HQrhYFibraLTTz8VLpryxwKBRxVg0OTMQm5vIPLJRYtuJzee6zwJQRgOWYB7dW00pydeX1Mv'); // Replace with your actual secret key

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);

// Get the total price from the request
$totalPrice = $input['totalPrice'];

try {
    // Create a new Checkout Session
    $session = \Stripe\Checkout\Session::create([
        'payment_method_types' => ['card'],
        'line_items' => [[
            'price_data' => [
                'currency' => 'usd', // Change to your currency
                'product_data' => [
                    'name' => 'Your Product', // Customize this
                ],
                'unit_amount' => $totalPrice * 100, // Amount in cents
            ],
            'quantity' => 1,
        ]],
        'mode' => 'payment',
        'success_url' => 'http://localhost/1/1/success.php', // Replace with your success URL
        'cancel_url' => 'https://localhost/1/1/cancel.php', // Replace with your cancel URL
    ]);

    // Respond with the session ID
    echo json_encode(['id' => $session->id]);
} catch (Exception $e) {
    // Handle error
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
