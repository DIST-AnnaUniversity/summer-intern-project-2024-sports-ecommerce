<?php
$hostname='localhost';
$username='root';
$password='';
$dbname='projectphp';
$conn=mysqli_connect($hostname,$username,$password,$dbname);
if(!$conn){
    die("Connection failed" .mysqli_connect_error());
}else{
    $num=$_POST['card'];
    $name=$_POST['name'];
    $cvv=$_POST['cvv'];
    $expiry=$_POST['expiry'];

    $query="INSERT INTO payment (cardno, cardname, expiry, cvv) VALUES ('$num', '$name', 'expiry', 'cvv')";
    $result= mysqli_query($conn, $query);

    if($result) {
        header("Location:paysuccess.php?");
    }else{
        echo "error";
    }
}


?>