<?php
session_start();
require 'vendor/autoload.php';

if (!class_exists('FPDF')) {
    die("Fpdf class not found!");
}

$orderDetails = $_SESSION['order_details'] ?? [];
$transactionId = $_SESSION['transaction_id'] ?? 'N/A'; // Assuming you store this in session
$purchaseDate = $_SESSION['purchase_date'] ?? date('Y-m-d'); // Assuming you store this in session

if (empty($orderDetails)) {
    echo "No order details available.";
    exit;
}

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

// Header
$pdf->Image('C:/xampp1/htdocs/1/1/images/Logo1.png', 10, 10, 40); // Update this line with your logo path
$pdf->Ln(10);

// Invoice Title
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, 'Order Invoice', 0, 1, 'C');
$pdf->Ln(5);

// Transaction details
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 10, 'Purchase Date: ' . $purchaseDate, 0, 1);
$pdf->Ln(5);

// Table header
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(60, 10, 'Product Name', 1);
$pdf->Cell(40, 10, 'Price', 1);
$pdf->Cell(40, 10, 'Quantity', 1);
$pdf->Cell(40, 10, 'Total', 1);
$pdf->Ln();

// Table data
$pdf->SetFont('Arial', '', 12);
$total = 0;
$maxLines = 10; // Limit the number of items to fit on one page
$count = 0;

foreach ($orderDetails as $item) {
    if ($count >= $maxLines) {
        break; // Stop if the maximum number of lines is reached
    }

    $itemQuantity = $item['quantity'] ?? 1; // Default to 1 if quantity not set
    $itemTotal = $item['price'] * $itemQuantity; // Calculate total for the item

    $pdf->Cell(60, 10, htmlspecialchars($item['name']), 1);
    $pdf->Cell(40, 10, 'Rs. ' . number_format($item['price'], 2), 1);
    $pdf->Cell(40, 10, $itemQuantity, 1); // Display quantity
    $pdf->Cell(40, 10, 'Rs. ' . number_format($itemTotal, 2), 1); // Display item total
    $pdf->Ln();
    $total += $itemTotal; // Add to overall total
    $count++;
}

// Total
$pdf->Cell(60, 10, 'Total:', 1);
$pdf->Cell(40, 10, '', 1);
$pdf->Cell(40, 10, '', 1);
$pdf->Cell(40, 10, 'Rs. ' . number_format($total, 2), 1);
$pdf->Ln(10);

// Thank you message
$pdf->SetFont('Arial', 'I', 12);
$pdf->Cell(0, 10, 'Thank you for your purchase!', 0, 1, 'C');

// Footer
$pdf->SetY(-15);
$pdf->SetFont('Arial', 'I', 8);
$pdf->Cell(0, 10, 'Page ' . $pdf->PageNo(), 0, 0, 'C');

$pdf->Output('D', 'invoice.pdf'); // D for download
exit;
?>
