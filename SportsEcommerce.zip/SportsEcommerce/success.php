<?php
session_start();
$orderDetails = $_SESSION['order_details'] ?? [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #4CAF50;
        }

        .invoice {
            margin-top: 20px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #fafafa;
        }

        .invoice-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }

        .total {
            font-weight: bold;
            font-size: 1.2em;
            margin-top: 10px;
            text-align: right;
        }

        .button {
            display: inline-block;
            margin: 20px 0;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
            text-align: center;
        }

        .button:hover {
            background-color: #45a049;
        }

        footer {
            text-align: center;
            margin-top: 20px;
            color: #888;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Payment Successful!</h1>

    <div class="invoice">
        <h2>Invoice Details</h2>
        <?php if (empty($orderDetails)): ?>
            <p>No order details available.</p>
        <?php else: ?>
            <?php $total = 0; ?>
            <?php foreach ($orderDetails as $item): ?>
                <div class="invoice-item">
                    <span><?php echo htmlspecialchars($item['name']); ?></span>
                    <span>Rs. <?php echo number_format($item['price'], 2); ?></span>
                </div>
                <?php $total += $item['price']; ?>
            <?php endforeach; ?>
            <div class="total">Total: Rs. <?php echo number_format($total, 2); ?></div>
        <?php endif; ?>
    </div>

    <a href="download-invoice.php" class="button"><i class="fas fa-file-download"></i> Download Invoice</a>
    <a href="buy2.html" class="button"><i class="fas fa-shopping-cart"></i> Continue Shopping</a>
</div>

<footer>
    <p>Thank you for your purchase!</p>
</footer>

</body>
</html>
