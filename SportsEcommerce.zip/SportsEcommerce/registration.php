<?php
include("db/config.php");
if(isset($_POST['submit'])) {
    $name=$_POST['name'];
    $email=$_POST['email'];
    $pass=$_POST['password'];
    $ph=$_POST['mobile'];

$result= mysqli_query($mysqli, "INSERT into users (id, name, email, pass, mobile) VALUES('','$name', '$email', '$pass', '$ph')");
if($result){
    header("Location: login.php?");
}  
else{
    header("Location: login.php?");
}
}

?>