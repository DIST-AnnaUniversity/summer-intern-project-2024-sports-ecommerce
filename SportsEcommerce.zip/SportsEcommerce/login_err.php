<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-image: url(bg1.jpg);
            background-position: right;
            background-size: cover;
            background-repeat: no-repeat;
            color: whitesmoke;
            font-weight: 600;
        }
        form {
            border: 1px solid antiquewhite;
            border-radius: 10px;
            padding: 20px;
            max-width: 350px;
            width: 90%;
            box-sizing: border-box;
            background-color: rgba(0,0,0,0.5);
            text-align: center; 
        }
        label {
            display: inline-block;
            width: 80px;
            text-align: right;
            padding-right: 10px;
        }
        input {
            width: 200px;
            margin-bottom: 10px;
            cursor: pointer;
        }

        h2 {
            margin-top: 0; 
        }

        button[type="submit"] {
            width: 100px;
            height: 30px;
            font-weight: 900;
            border-radius: 10px;
            color: whitesmoke;
            margin: 0 auto; 
            background-color:green;
        }

        button[type="submit"]:hover{
            background-color: lightgreen;
            color: black;
        }

        a{
            text-decoration: none;
        }

        a:link{
            color: burlywood;
        }

        a:hover{
            color: blanchedalmond;
            text-decoration: underline;
        }

        a:visited{
            color:burlywood;
        }

        @media (max-width: 500px) {
            form {
                max-width: 100%;
            }
            label {
                width: 100%;
                text-align: left;
            }
            input {
                width: 100%;
            }
        }
    </style>
</head>
<body>
<form action="process.php" method='post'>
    
    <?php
    if(isset($_GET['error'])) {
        echo $_GET['error'];
    }
    ?>
    

    <h2>Login Page</h2><br>
    <label for="name">Username:</label>
    <input type="text" id="name" name='name'><br><br>
    <label for="pass">Password&nbsp;:</label>
    <input type="password" id="pass" name='pass'><br><br>
    <button type='submit'>Login</button><br>
    <p style="color: white">Username or Password is incorrect!!!</p>
    
</form>
</body>
</html>