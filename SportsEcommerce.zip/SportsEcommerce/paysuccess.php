<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        p{
            font-size 55px;
        }
    </style>
</head>
<body>
    <center>
        <p>Payment Successful!!!</p>
        <p>Thank you for Purchasing!!!</p>
        <a href="index.html"><input type="submit" value="Back to home"></a><br>
        <a href="logout.php"><input type="submit" value="Logout"></a>
    </center>
</body>
</html>