<?php
session_start();
if (!isset($_SESSION['name']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        /* Same styles as admin_panel.php for consistency */
    </style>
</head>
<body>

<header>
    <h1>User Management</h1>
    <nav>
        <a href="admin_panel.php">Dashboard</a>
        <a href="logout.php">Logout</a>
    </nav>
</header>

<div class="container">
    <h2>Manage Users</h2>
    <p>List of registered users will be displayed here.</p>
    <!-- Add your user table and management options here -->
</div>

<footer>
    <p>&copy; 2024 Your Company</p>
</footer>

</body>
</html>
