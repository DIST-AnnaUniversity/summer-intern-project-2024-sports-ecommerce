<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Canceled</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to your main CSS if needed -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(to right, #f8f9fa, #e9ecef);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            color: #343a40;
            text-align: center;
        }

        h1 {
            font-size: 3rem;
            color: #dc3545; /* Bootstrap danger color */
            margin-bottom: 20px;
        }

        p {
            font-size: 1.5rem;
            margin: 20px 0;
            line-height: 1.5;
        }

        .button {
            padding: 12px 24px;
            font-size: 1.2rem;
            color: white;
            background-color: #007bff; /* Bootstrap primary color */
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .button:hover {
            background-color: #0056b3; /* Darker blue on hover */
            transform: translateY(-2px);
        }

        .link {
            margin-top: 15px;
            text-decoration: none;
            color: #007bff; /* Bootstrap primary color */
            font-size: 1.2rem;
            transition: color 0.3s;
        }

        .link:hover {
            text-decoration: underline;
            color: #0056b3; /* Darker blue on hover */
        }

        .container {
            background: white;
            border-radius: 10px;
            padding: 40px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 600px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Payment Canceled</h1>
        <p>We’re sorry to see you go! Your payment has been canceled successfully.</p>
        <p>If you have any questions or need assistance, feel free to <a href="contact.html" class="link">contact us</a>.</p>
        <button class="button" onclick="window.location.href='index.html'">Return to Shopping</button>
    </div>

</body>
</html>
