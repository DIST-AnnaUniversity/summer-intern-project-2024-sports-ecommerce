<?php
include('db/config.php');
session_start();

if (isset($_POST['name']) && isset($_POST['pass'])) {
    $name = ($_POST['name']);
    $pass = ($_POST['pass']);

    if (empty($name)) {
        header("Location:user_empty.php?");
        exit();
    } else if (empty($pass)) {
        header("Location:pass_empty.php?");
        exit();
    } else {
        // Check for user credentials
        $sql = "SELECT * FROM users WHERE name='$name' AND pass='$pass'";
        $result = mysqli_query($mysqli, $sql);

        if (mysqli_num_rows($result)) {
            $row = mysqli_fetch_assoc($result);
            $_SESSION['name'] = $row['name'];
            $_SESSION['id'] = $row['id'];

            // Check if the user is an admin
            if ($row['name'] === 'admin') {  // Ensure you have a 'role' column in your users table
                $_SESSION['admin_logged_in'] = true;
                header("Location:dashboard.php"); // Redirect to admin dashboard
            } else {
                header("Location:index.html?"); // Redirect to user home page
            }
            exit();
        } else {
            header("Location:login_err.php?");
            exit();
        }
    }
}
?>
