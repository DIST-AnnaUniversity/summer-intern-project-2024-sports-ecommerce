<?php
$hostname='localhost';
$username='root';
$password='';
$databasename='projectphp1';

$mysqli= mysqli_connect($hostname, $username, $password, $databasename);



?>