<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Admin Dashboard</h1>
        <a href="logout.php" class="logout">Logout</a>
    </header>

    <nav>
        <ul>
            <li><a href="#">Dashboard</a></li>
            <li><a href="#">Users</a></li>
            <li><a href="#">Products</a></li>
            <li><a href="#">Orders</a></li>
            <li><a href="#">Reports</a></li>
        </ul>
    </nav>

    <main>
        <h2>Overview</h2>
        <div class="card-container">
            <div class="card">
                <h3>Total Sales</h3>
                <p>$12,345</p>
            </div>
            <div class="card">
                <h3>Total Users</h3>
                <p>1,234</p>
            </div>
            <div class="card">
                <h3>Total Products</h3>
                <p>567</p>
            </div>
            <div class="card">
                <h3>Recent Orders</h3>
                <p>20</p>
            </div>
        </div>
    </main>

    <footer>
        &copy; 2024 EliteSportfiy. All Rights Reserved.
    </footer>
</body>
</html>
