<?php
session_start();

$input = json_decode(file_get_contents('php://input'), true);
$_SESSION['order_details'] = $input; // Store the cart details in session

echo json_encode(['status' => 'success']);
?>
